
# TACACS+ & RADIUS Config Web App

A Spring Boot application with Thymeleaf UI to manage and validate tac_plus and FreeRADIUS configurations.

## Features

- Edit /etc/tacacs/tac_plus.conf
- Edit /etc/freeradius/3.0/users
- Restart TACACS+ and RADIUS services
- Validate configurations
- View recent system logs
- Backup & download configs

## Build & Run

```bash
./mvnw clean package
java -jar target/tacconfig-0.0.1-SNAPSHOT.jar
```

Login with `admin` / `admin123` via HTTP Basic Auth.
