#!/usr/bin/env python3
import os
import sqlite3
import io
import json
import base64
import re
import threading
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, send_file, flash
from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa
import requests
from requests_ntlm import HttpNtlmAuth
from bs4 import BeautifulSoup
from apscheduler.schedulers.background import BackgroundScheduler
import smtplib
from email.message import EmailMessage
import urllib3

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "data.db")
CONFIG_PATH = os.path.join(BASE_DIR, "config.json")
ADCS_BASE_URL = "https://p077pkipiss01/certsrv"

app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "dev-secret-change-me")

# --- Database helpers ---
def init_db():
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(\"\"\"
    CREATE TABLE IF NOT EXISTS requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        common_name TEXT,
        san TEXT,
        key_size INTEGER,
        template TEXT,
        request_id TEXT,
        csr TEXT,
        private_key TEXT,
        cert TEXT,
        email TEXT,
        status TEXT,
        created_at TEXT,
        updated_at TEXT
    )
    \"\"\")
    conn.commit()
    conn.close()

def db_execute(query, params=(), fetch=False):
    conn = sqlite3.connect(DB_PATH)
    cur = conn.cursor()
    cur.execute(query, params)
    if fetch:
        rows = cur.fetchall()
        conn.close()
        return rows
    conn.commit()
    conn.close()
    return None

# Initialize DB
init_db()

# Load config (SMTP settings, etc)
default_config = {
    "smtp": {
        "host": "smtp.example.com",
        "port": 587,
        "starttls": True,
        "username": "user@example.com",
        "password": "password",
        "from": "no-reply@example.com"
    }
}
if not os.path.exists(CONFIG_PATH):
    with open(CONFIG_PATH, "w") as f:
        json.dump(default_config, f, indent=2)
with open(CONFIG_PATH) as f:
    CONFIG = json.load(f)

# --- PKI helpers ---
def fetch_templates(username, password):
    session = requests.Session()
    session.auth = HttpNtlmAuth(username, password)
    resp = session.get(f"{ADCS_BASE_URL}/certfnsh.asp", verify=False, timeout=20)
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")
    templates = []
    # Heuristic: options that look like templates (skip empty and separators)
    for option in soup.find_all("option"):
        val = option.get("value", "").strip()
        if val and not val.startswith("----"):
            templates.append(val)
    return templates

def submit_csr_to_adcs(csr_pem, template, username, password):
    session = requests.Session()
    session.auth = HttpNtlmAuth(username, password)
    data = {
        "Mode": "newreq",
        "CertRequest": csr_pem,
        "CertAttrib": f"CertificateTemplate:{template}",
        "TargetStoreFlags": "0",
        "SaveCert": "yes"
    }
    resp = session.post(f"{ADCS_BASE_URL}/certfnsh.asp", data=data, verify=False, timeout=30)
    resp.raise_for_status()
    # Try to extract Request ID from body
    match = re.search(r"Request ID\s*:?\s*(\d+)", resp.text, re.IGNORECASE)
    request_id = match.group(1) if match else None
    # Some deployments show the ID differently; try other heuristics
    if not request_id:
        # look for "Request" followed by digits
        match = re.search(r"Request\s*(\d+)", resp.text)
        if match:
            request_id = match.group(1)
    return request_id, resp.text

def retrieve_cert_for_request(request_id, username, password):
    session = requests.Session()
    session.auth = HttpNtlmAuth(username, password)
    url = f"{ADCS_BASE_URL}/certnew.cer?ReqID={request_id}&Enc=b64"
    resp = session.get(url, verify=False, timeout=20)
    if resp.status_code != 200:
        return None, resp.status_code, resp.text
    body = resp.text.strip()
    # If it already returns PEM, keep it
    if "-----BEGIN CERTIFICATE-----" in body:
        pem = body
    else:
        # Sometimes ADCS returns raw base64 text (no headers). Wrap
        b64 = re.sub(r"\s+", "", body)
        try:
            decoded = base64.b64decode(b64)
            # Try to detect DER and convert to PEM
            pem_bytes = base64.b64encode(decoded).decode()
            pem = "-----BEGIN CERTIFICATE-----\n"
            # wrap at 64 chars
            for i in range(0, len(pem_bytes), 64):
                pem += pem_bytes[i:i+64] + "\n"
            pem += "-----END CERTIFICATE-----\n"
        except Exception:
            # Fallback: return raw body as-is
            pem = body
    return pem, resp.status_code, resp.text

# --- Email helper ---
def send_email(to_address, subject, body, attachments=None):
    cfg = CONFIG.get("smtp", {})
    if not cfg.get("host"):
        app.logger.warning("SMTP not configured; skipping email")
        return False
    msg = EmailMessage()
    msg["From"] = cfg.get("from", cfg.get("username", "no-reply@example.com"))
    msg["To"] = to_address
    msg["Subject"] = subject
    msg.set_content(body)
    # attachments: list of tuples (filename, bytes, mimetype)
    if attachments:
        for fn, data, mtype in attachments:
            msg.add_attachment(data, maintype=mtype.split("/")[0], subtype=mtype.split("/")[1], filename=fn)
    try:
        if cfg.get("starttls", True):
            server = smtplib.SMTP(cfg["host"], cfg.get("port", 587), timeout=10)
            server.ehlo()
            server.starttls()
            server.login(cfg.get("username"), cfg.get("password"))
        else:
            server = smtplib.SMTP(cfg["host"], cfg.get("port", 25), timeout=10)
            if cfg.get("username"):
                server.login(cfg.get("username"), cfg.get("password"))
        server.send_message(msg)
        server.quit()
        return True
    except Exception as e:
        app.logger.exception("Failed to send email: %s", e)
        return False

# --- Background checker ---
lock = threading.Lock()

def check_pending_requests():
    app.logger.info("Background check started")
    rows = db_execute("SELECT id, request_id, email FROM requests WHERE status = 'pending'", fetch=True)
    if not rows:
        app.logger.info("No pending requests")
        return
    for row in rows:
        rec_id, req_id, email = row
        if not req_id or req_id == "UNKNOWN":
            continue
        # For retrieval we need username/password saved per-ticket; in this design user does not store password.
        # So we rely on a stored 'proxy' username/password in config for server-side checks (service account).
        svc_user = CONFIG.get("service_account", {}).get("username")
        svc_pass = CONFIG.get("service_account", {}).get("password")
        if not svc_user or not svc_pass:
            app.logger.warning("No service account configured for background retrieval; skip")
            continue
        try:
            pem, status_code, raw = retrieve_cert_for_request(req_id, svc_user, svc_pass)
            if pem and "BEGIN CERTIFICATE" in pem:
                # found cert - update DB
                db_execute("UPDATE requests SET cert = ?, status = 'issued', updated_at = ? WHERE id = ?",
                           (pem, datetime.utcnow().isoformat(), rec_id))
                app.logger.info("Request %s issued", req_id)
                # notify user if email present
                if email:
                    subject = f"Certificate issued for Request {req_id}"
                    body = f"Your certificate request (ID {req_id}) has been issued. You can download it from the dashboard."
                    # attach cert as file
                    send_email(email, subject, body, attachments=[(f"cert_{req_id}.pem", pem.encode(), "application/x-pem-file")])
        except Exception as e:
            app.logger.exception("Error checking request %s: %s", req_id, e)

scheduler = BackgroundScheduler()
scheduler.add_job(check_pending_requests, "interval", minutes=10, id="pki_check_job", replace_existing=True)
scheduler.start()

# --- Web routes ---
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        common_name = request.form.get("common_name")
        san = request.form.get("san", "")
        key_size = int(request.form.get("key_size", 4096))
        template = request.form.get("template")
        username = request.form.get("username")
        password = request.form.get("password")
        email = request.form.get("email", "").strip() or None

        # generate key & csr
        private_key = rsa.generate_private_key(public_exponent=65537, key_size=key_size)
        subject = x509.Name([x509.NameAttribute(NameOID.COMMON_NAME, common_name)])
        san_list = [x509.DNSName(s.strip()) for s in san.split(",") if s.strip()]
        csr_builder = x509.CertificateSigningRequestBuilder().subject_name(subject)
        if san_list:
            csr_builder = csr_builder.add_extension(x509.SubjectAlternativeName(san_list), critical=False)
        csr = csr_builder.sign(private_key, hashes.SHA256())
        csr_pem = csr.public_bytes(serialization.Encoding.PEM).decode()
        private_key_pem = private_key.private_bytes(encoding=serialization.Encoding.PEM,
                                                   format=serialization.PrivateFormat.TraditionalOpenSSL,
                                                   encryption_algorithm=serialization.NoEncryption()).decode()

        # submit CSR to ADCS
        request_id = None
        try:
            request_id, raw = submit_csr_to_adcs(csr_pem, template, username, password)
        except Exception as e:
            flash(f"Error submitting CSR to ADCS: {e}", "danger")
            # still save the CSR and key so user can retry
            request_id = "UNKNOWN"
        # store in DB
        now = datetime.utcnow().isoformat()
        db_execute("""INSERT INTO requests (common_name, san, key_size, template, request_id, csr, private_key, cert, email, status, created_at, updated_at)
                      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                   (common_name, san, key_size, template, request_id, csr_pem, private_key_pem, None, email, "pending", now, now))
        # redirect to dashboard
        return redirect(url_for("dashboard"))
    # GET: show form. If user wants to prefetch templates, show small login box
    return render_template("index.html")

@app.route("/fetch_templates", methods=["POST"])
def fetch_templates_route():
    username = request.form.get("username")
    password = request.form.get("password")
    try:
        templates = fetch_templates(username, password)
        return {"templates": templates}
    except Exception as e:
        return {"error": str(e)}, 400

@app.route("/dashboard")
def dashboard():
    rows = db_execute("SELECT id, common_name, san, key_size, template, request_id, email, status, created_at FROM requests ORDER BY created_at DESC", fetch=True)
    return render_template("dashboard.html", rows=rows)

@app.route("/download/<int:rid>")
def download(rid):
    row = db_execute("SELECT id, request_id, private_key, cert FROM requests WHERE id = ?", (rid,), fetch=True)
    if not row:
        flash("Request not found", "danger")
        return redirect(url_for("dashboard"))
    _, request_id, pk, cert = row[0]
    output = io.BytesIO()
    output.write(pk.encode())
    output.write(b"\n")
    if cert:
        output.write(cert.encode())
    output.seek(0)
    return send_file(output, as_attachment=True, download_name=f"cert_{request_id or rid}.pem", mimetype="application/x-pem-file")

@app.route("/details/<int:rid>")
def details(rid):
    row = db_execute("SELECT id, common_name, san, key_size, template, request_id, csr, private_key, cert, email, status, created_at FROM requests WHERE id = ?", (rid,), fetch=True)
    if not row:
        flash("Request not found", "danger")
        return redirect(url_for("dashboard"))
    record = row[0]
    return render_template("details.html", rec=record)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5000, debug=True)
