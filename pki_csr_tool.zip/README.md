Epiq CSR & ADCS Enrollment Tool
--------------------------------
Quick start:
  1. Create a Python virtualenv: python -m venv venv
  2. Activate and install requirements: pip install -r requirements.txt
  3. Edit config.json to set SMTP and optional service account credentials.
     - service_account.username and .password are used by the background checker to poll ADCS.
  4. Run: python app.py
  5. Open http://localhost:5000/

Notes:
  - This app submits CSRs to an ADCS web enrollment server (https://p077pkipiss01/certsrv).
  - The background worker checks pending requests every 10 minutes and will email users if they provided an email.
  - For background retrieval to work without user credentials, set a service account in config.json with permission to view issued certs.
