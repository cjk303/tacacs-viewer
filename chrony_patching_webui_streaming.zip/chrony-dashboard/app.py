
from flask import Flask, render_template, request, redirect, url_for, session, send_from_directory, flash
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from ldap3 import Server, Connection, SIMPLE, ALL
from flask_socketio import SocketIO, emit, join_room, leave_room
import subprocess
import threading
import os
from datetime import datetime
from pathlib import Path

# Configuration
APP_ROOT = Path(__file__).parent
HOSTFILES_DIR = APP_ROOT / "hostfiles"
SNAPDIR = APP_ROOT / "snapshots"
UTIL_BASE = Path("/opt/ansible/utils")  # used by preparepatching (optional)
CREDS = Path.home() / ".pwsh_cred"

LDAP_SERVER = "ldap://amer.epiqcorp.com"
LDAP_DOMAIN = "AMER"

# Flask + Login + SocketIO
app = Flask(__name__)
app.secret_key = os.environ.get("FLASK_SECRET", "change_this_secret")
login_manager = LoginManager(app)
login_manager.login_view = "login"
# Use eventlet for Socket.IO server (systemd unit will need to run with eventlet)
socketio = SocketIO(app, async_mode="eventlet")

# Simple User class
class User(UserMixin):
    def __init__(self, username):
        self.id = username
        self.name = username

@login_manager.user_loader
def load_user(user_id):
    return User(user_id)

# Routes

@app.route("/login", methods=["GET", "POST"])
def login():
    error = None
    if request.method == "POST":
        username = request.form["username"]
        password = request.form["password"]
        user_upn = f"{username}@amer.epiqcorp.com"
        try:
            server = Server(LDAP_SERVER, get_info=ALL)
            conn = Connection(server, user=user_upn, password=password, authentication=SIMPLE, auto_bind=True)
            login_user(User(username))
            return redirect(url_for("menu"))
        except Exception:
            try:
                user_dn = f"{LDAP_DOMAIN}\\{username}"
                server = Server(LDAP_SERVER, get_info=ALL)
                conn = Connection(server, user=user_dn, password=password, authentication="NTLM", auto_bind=True)
                login_user(User(username))
                return redirect(url_for("menu"))
            except Exception:
                error = "Invalid credentials or domain issue"
    return render_template("login.html", error=error)

@app.route("/logout")
@login_required
def logout():
    logout_user()
    session.clear()
    return redirect(url_for("login"))

@app.route("/")
@login_required
def menu():
    selected = session.get("selected_file")
    prep_done = session.get("prep_done", False)
    snap_done = session.get("snap_done", False)
    new_dir = session.get("new_dir", "")
    return render_template("menu.html", selected_file=selected, prep_done=prep_done, snap_done=snap_done, new_dir=new_dir)

@app.route("/browse")
@login_required
def browse():
    HOSTFILES_DIR.mkdir(exist_ok=True)
    entries = []
    for p in sorted(HOSTFILES_DIR.iterdir()):
        entries.append({
            "name": p.name,
            "is_dir": p.is_dir(),
            "size": p.stat().st_size if p.is_file() else None
        })
    return render_template("browse.html", entries=entries)

@app.route("/select", methods=["POST"])
@login_required
def select():
    filename = request.form.get("filename")
    target = HOSTFILES_DIR / filename
    if not target.exists():
        flash("Selected file does not exist.", "error")
    else:
        session["selected_file"] = str(target)
        session.pop("prep_done", None)
        session.pop("snap_done", None)
        session.pop("new_dir", None)
    return redirect(url_for("menu"))

@app.route("/view_hosts")
@login_required
def view_hosts():
    selected = session.get("selected_file")
    if not selected:
        flash("No hosts file selected.", "error")
        return redirect(url_for("menu"))
    content = Path(selected).read_text()
    return render_template("view_hosts.html", content=content, filename=Path(selected).name)

@app.route("/static/<path:filename>")
def static_files(filename):
    return send_from_directory(APP_ROOT / "static", filename)

# Streaming subprocess helper
def stream_subprocess(cmd, sid):
    process = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, env=os.environ)
    socketio.emit("proc_started", {"cmd": cmd}, room=sid)
    try:
        for line in process.stdout:
            socketio.emit("proc_output", {"line": line.rstrip("\n")}, room=sid)
    except Exception as e:
        socketio.emit("proc_output", {"line": f"[error streaming output] {e}"}, room=sid)
    rc = process.wait()
    socketio.emit("proc_finished", {"returncode": rc}, room=sid)
    return rc

def run_action(action, sid):
    selected = session.get("selected_file")
    whoami = os.getenv("USER") or os.getlogin()
    date_str = datetime.now().strftime("%Y-%m-%d")
    new_dir = f"{whoami}_{date_str}"
    new_dir_path = APP_ROOT / new_dir

    if action == "list_hosts":
        if not selected:
            socketio.emit("proc_output", {"line": "No hosts file selected."}, room=sid)
            socketio.emit("proc_finished", {"returncode": 1}, room=sid)
            return
        cmd = f"pr -ts' ' --columns 3 '{selected}' || cat '{selected}'"
        stream_subprocess(cmd, sid)
    elif action == "prepare":
        if not selected:
            socketio.emit("proc_output", {"line": "No hosts file selected."}, room=sid)
            socketio.emit("proc_finished", {"returncode": 1}, room=sid)
            return
        new_dir_path.mkdir(exist_ok=True)
        host_details = new_dir_path / "host_details"
        ansible_hosts = new_dir_path / "ansible_hosts"
        vm_names = new_dir_path / "vm_names"
        vcenter = new_dir_path / "vcenter"
        for f in [host_details, ansible_hosts, vm_names, vcenter]:
            if f.exists():
                f.unlink()
        socketio.emit("proc_output", {"line": f"Preparing patching in {new_dir_path}"}, room=sid)
        with open(selected, "r") as fh:
            lines = [l.strip() for l in fh if l.strip()]
        for each in lines:
            try:
                ip = subprocess.check_output(f"getent hosts {each} | awk '{{print $1}}'", shell=True, text=True).strip()
            except subprocess.CalledProcessError:
                ip = ""
            vm_name = ""
            try:
                if ip:
                    vm_name = subprocess.check_output(f"lookup -v "{ip}," | awk -F, '{{print $1}}'", shell=True, text=True).strip()
            except subprocess.CalledProcessError:
                vm_name = ""
            if not ip:
                socketio.emit("proc_output", {"line": f"[ERROR] IP address not found for {each}"}, room=sid)
                socketio.emit("proc_finished", {"returncode": 2}, room=sid)
                return
            if not vm_name:
                socketio.emit("proc_output", {"line": f"[WARN] VM name not found for {each} (lookup missing or returned empty)"}, room=sid)
            with open(host_details, "a") as hd:
                hd.write(f"{each} {ip} {vm_name}\n")
            with open(ansible_hosts, "a") as ah:
                ah.write(f"{ip}\n")
            with open(vm_names, "a") as vn:
                vn.write(f"{vm_name}\n")
            try:
                res = subprocess.check_output(f"grep -il {ip} {UTIL_BASE}/*.csv 2>/dev/null | sed -e 's|.csv$||' -e 's|^.*/||' || true", shell=True, text=True).strip()
                if res:
                    with open(vcenter, "a") as vc:
                        vc.write(res + "\n")
            except Exception:
                pass
            socketio.emit("proc_output", {"line": f"Processed {each} -> {ip} {vm_name}"}, room=sid)
        vcenters = set()
        if vcenter.exists():
            with open(vcenter, "r") as vc:
                vcenters = set([l.strip() for l in vc if l.strip()])
        if len(vcenters) != 1:
            socketio.emit("proc_output", {"line": f"[ERROR] You can only patch systems in a single vcenter at a time. Found: {len(vcenters)}"}, room=sid)
            socketio.emit("proc_finished", {"returncode": 3}, room=sid)
            return
        session["prep_done"] = True
        session["new_dir"] = str(new_dir_path)
        socketio.emit("proc_output", {"line": f"Prepared directory {new_dir_path}"}, room=sid)
        socketio.emit("proc_finished", {"returncode": 0}, room=sid)
    elif action == "snapshot":
        new_dir_sess = session.get("new_dir")
        if not new_dir_sess:
            socketio.emit("proc_output", {"line": "Patching not prepared (no NEW_DIR). Run Prepare first."}, room=sid)
            socketio.emit("proc_finished", {"returncode": 1}, room=sid)
            return
        if not CREDS.exists():
            socketio.emit("proc_output", {"line": f"[ERROR] Powershell credentials file {CREDS} does not exist."}, room=sid)
            socketio.emit("proc_finished", {"returncode": 2}, room=sid)
            return
        vm_names = Path(new_dir_sess) / "vm_names"
        vcenter = Path(new_dir_sess) / "vcenter"
        cmd = f""{SNAPDIR}/take_snapshots.pwsh" -cred "{CREDS}" -name "{new_dir_sess}" -vcenter "{vcenter}" -vms "{vm_names}""
        stream_subprocess(cmd, sid)
        session["snap_done"] = True
    elif action in ("patch", "reboot", "uptime"):
        selected = session.get("selected_file")
        if not selected:
            socketio.emit("proc_output", {"line": "No hosts file selected."}, room=sid)
            socketio.emit("proc_finished", {"returncode": 1}, room=sid)
            return
        playbook_map = {
            "patch": "yaml/patch.yml",
            "reboot": "yaml/reboot.yml",
            "uptime": "yaml/uptime.yml"
        }
        pb = playbook_map.get(action)
        cmd = f"ansible-playbook --ask-pass --become --ask-become-pass -i '{selected}' '{pb}'"
        stream_subprocess(cmd, sid)
    else:
        socketio.emit("proc_output", {"line": f"Unknown action: {action}"}, room=sid)
        socketio.emit("proc_finished", {"returncode": 1}, room=sid)

@socketio.on("connect")
def on_connect():
    if not current_user.is_authenticated:
        return False
    sid = request.sid
    join_room(sid)
    emit("connected", {"msg": "connected", "sid": sid})

@socketio.on("disconnect")
def on_disconnect():
    sid = request.sid
    try:
        leave_room(sid)
    except Exception:
        pass

@socketio.on("start_action")
def on_start_action(data):
    if not current_user.is_authenticated:
        emit("proc_output", {"line": "Not authenticated"})
        emit("proc_finished", {"returncode": 1})
        return
    action = data.get("action")
    sid = request.sid
    thread = threading.Thread(target=run_action, args=(action, sid), daemon=True)
    thread.start()

if __name__ == "__main__":
    socketio.run(app, host="0.0.0.0", port=5000)
