import os
import shutil
import glob
from datetime import datetime
from flask import Flask, render_template, request, redirect, url_for, flash

app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Change this in production

# Configuration paths
TACACS_CONF = '/etc/tacacs/tacacs.conf'
FREERADIUS_CONF = '/etc/freeradius/clients.conf'
BACKUP_DIR = '/etc/tacacs/backups'

# Ensure backup directory exists
os.makedirs(BACKUP_DIR, exist_ok=True)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/backups')
def backups():
    tacacs_backups = sorted(glob.glob(os.path.join(BACKUP_DIR, 'tacacs.conf.bak.*')), reverse=True)
    freeradius_backups = sorted(glob.glob(os.path.join(BACKUP_DIR, 'freeradius.clients.conf.bak.*')), reverse=True)
    return render_template('backups.html', tacacs_backups=tacacs_backups, freeradius_backups=freeradius_backups)

@app.route('/backups/restore', methods=['POST'])
def restore_backup():
    file_path = request.form.get('file_path')
    if file_path and os.path.exists(file_path):
        try:
            if 'tacacs.conf.bak' in file_path:
                shutil.copy2(file_path, TACACS_CONF)
            elif 'freeradius.clients.conf.bak' in file_path:
                shutil.copy2(file_path, FREERADIUS_CONF)
            flash(f'Restored backup: {os.path.basename(file_path)}', 'success')
        except Exception as e:
            flash(f'Error restoring backup: {e}', 'error')
    else:
        flash('Backup file not found.', 'error')
    return redirect(url_for('backups'))

@app.route('/backups/delete', methods=['POST'])
def delete_backup():
    file_path = request.form.get('file_path')
    if file_path and os.path.exists(file_path):
        try:
            os.remove(file_path)
            flash(f'Deleted backup: {os.path.basename(file_path)}', 'success')
        except Exception as e:
            flash(f'Error deleting backup: {e}', 'error')
    else:
        flash('Backup file not found.', 'error')
    return redirect(url_for('backups'))

@app.route('/users_groups', methods=['GET', 'POST'])
def users_groups():
    if request.method == 'POST':
        updated_config = request.form.get('config')
        try:
            backup_path = os.path.join(BACKUP_DIR, f'tacacs.conf.bak.{datetime.now().strftime("%Y%m%d%H%M%S")}')
            shutil.copy2(TACACS_CONF, backup_path)
            with open(TACACS_CONF, 'w') as f:
                f.write(updated_config)
            flash('Configuration saved and backup created.', 'success')
        except Exception as e:
            flash(f'Failed to save config: {e}', 'error')
        return redirect(url_for('users_groups'))

    try:
        with open(TACACS_CONF, 'r') as f:
            config = f.read()
    except Exception as e:
        flash(f'Could not read config file: {e}', 'error')
        config = ''
    return render_template('users_groups.html', config=config)

@app.route('/restart_tacacs', methods=['POST'])
def restart_tacacs():
    try:
        os.system('docker restart tacacs_plus')
        flash('TACACS+ container restarted successfully.', 'success')
    except Exception as e:
        flash(f'Error restarting TACACS+: {e}', 'error')
    return redirect(url_for('index'))

@app.route('/restart_freeradius', methods=['POST'])
def restart_freeradius():
    try:
        os.system('systemctl restart freeradius')
        flash('FreeRADIUS service restarted successfully.', 'success')
    except Exception as e:
        flash(f'Error restarting FreeRADIUS: {e}', 'error')
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
